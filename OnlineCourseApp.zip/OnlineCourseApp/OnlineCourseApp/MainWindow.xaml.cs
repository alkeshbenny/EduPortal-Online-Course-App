﻿using OnlineCourseApp.Models;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;

namespace OnlineCourseApp
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();

            // Set focus to email textbox when window loads
            this.Loaded += (s, e) => txtEmail.Focus();

            // Allow Enter key to trigger login
            this.KeyDown += LoginWindow_KeyDown;
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Simplified login - just navigate to CourseBrowser
                // You can add validation back later when needed

                // Show loading state briefly
                SetLoadingState(true);

                // Set a default student ID for testing (you can change this)
                int defaultStudentId = 1;
                string defaultStudentName = "Test Student";

                // Store current user session
                Application.Current.Properties["CurrentStudentId"] = defaultStudentId;
                Application.Current.Properties["CurrentStudentName"] = defaultStudentName;

                // Small delay to show loading state
                System.Threading.Thread.Sleep(500);

                // Open main application window
                var browser = new CourseBrowser(defaultStudentId);
                browser.Show();

                // Close login window
                this.Close();
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"An error occurred: {ex.Message}");
            }
            finally
            {
                SetLoadingState(false);
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            // Confirm before closing
            var result = MessageBox.Show(
                "Are you sure you want to exit the application?",
                "Confirm Exit",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }

        private void LoginWindow_KeyDown(object sender, KeyEventArgs e)
        {
            // Allow Enter key to trigger login
            if (e.Key == Key.Enter)
            {
                LoginButton_Click(sender, e);
            }
            // Allow Escape key to close window
            else if (e.Key == Key.Escape)
            {
                CloseButton_Click(sender, e);
            }
        }

        private void SetLoadingState(bool isLoading)
        {
            // Find the login button
            var loginButton = FindName("LoginButton") as System.Windows.Controls.Button;

            if (loginButton != null)
            {
                loginButton.Content = isLoading ? "Signing In..." : "Sign In";
                loginButton.IsEnabled = !isLoading;
            }

            // Disable input fields during loading
            txtEmail.IsEnabled = !isLoading;
            txtPassword.IsEnabled = !isLoading;

            // Change cursor
            this.Cursor = isLoading ? Cursors.Wait : Cursors.Arrow;
        }

        private void ShowErrorMessage(string message)
        {
            MessageBox.Show(
                message,
                "Error",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }

        // Event handlers for additional UI interactions
        private void ForgotPassword_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Forgot Password feature will be implemented soon.\nPlease contact your administrator for password reset.",
                "Forgot Password",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        private void SignUp_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Student Registration feature will be implemented soon.\nPlease contact your administrator to create an account.",
                "Student Registration",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        // Override window closing to ensure proper application shutdown
        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            // If this is the main login window and no other windows are open,
            // closing it should shut down the application
            if (Application.Current.Windows.Count == 1)
            {
                Application.Current.Shutdown();
            }
            base.OnClosing(e);
        }
    }
}