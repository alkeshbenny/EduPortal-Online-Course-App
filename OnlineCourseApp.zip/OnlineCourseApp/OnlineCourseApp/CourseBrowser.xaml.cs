﻿using OnlineCourseApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OnlineCourseApp
{
    /// <summary>
    /// Interaction logic for CourseBrowser.xaml
    /// </summary>
    public partial class CourseBrowser : Window
    {
        private int studentId;

        public CourseBrowser(int studentId)
        {
            InitializeComponent();
            this.studentId = studentId;
            LoadCourses();
        }

        private void LoadCourses(string searchTerm = "")
        {
            using var db = new AppDbContext();

            var courses = db.Courses.AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                courses = courses.Where(c =>
                    (c.Title != null && c.Title.Contains(searchTerm)) ||
                    (c.Category != null && c.Category.Contains(searchTerm)));
            }

            dgCourses.ItemsSource = courses.ToList();
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            LoadCourses(txtSearch.Text.Trim());
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            txtSearch.Text = "";
            LoadCourses();
        }

        private void Enroll_Click(object sender, RoutedEventArgs e)
        {
            if (dgCourses.SelectedItem is not Course selectedCourse)
            {
                MessageBox.Show("Please select a course to enroll.");
                return;
            }

            using var db = new AppDbContext();

            // Check if already enrolled
            var alreadyEnrolled = db.Enrollments
                .Any(e => e.StudentID == studentId && e.CourseID == selectedCourse.CourseID);

            if (alreadyEnrolled)
            {
                MessageBox.Show("You are already enrolled in this course.");
                return;
            }

            // Enroll
            var enrollment = new Enrollment
            {
                StudentID = studentId,
                CourseID = selectedCourse.CourseID,
                EnrollmentDate = DateTime.Now
            };

            db.Enrollments.Add(enrollment);
            db.SaveChanges();

            MessageBox.Show("Enrollment successful!");
        }
    }
}
